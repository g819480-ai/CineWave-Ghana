# NOCTURA — Plex API integration patch

This patch adds a server-side Plex catalogue API to the existing Cloudflare Worker.

It does not replace your existing D1/R2 movie API, website design, or database. It does not copy movie files from Plex into Cloudflare R2.

## Files

- `plex.js` — Plex API handler. Put it beside `worker.js`.
- `WORKER_INTEGRATION.txt` — the two small changes needed in `worker.js`.

## Cloudflare variables

In Cloudflare Dashboard, open the Worker that serves NOCTURA, then Settings → Variables and Secrets.

Add these as **Secrets** (not public text variables):

- `PLEX_URL` — your Plex server's public HTTPS address, for example `https://plex.example.com:32400`
- `PLEX_TOKEN` — your private Plex authentication token

Optional ordinary variable:

- `PLEX_CLIENT_ID` — a stable identifier such as `noctura-plex-client`
- `PLEX_MOVIE_SECTION_ID` — the numeric ID of your Plex movie library. If omitted, the API checks all movie sections.

Never paste the Plex token into website JavaScript, a public GitHub file, or a chat.

## API endpoints

- `GET /api/plex/health`
- `GET /api/plex/sections`
- `GET /api/plex/movies`
- `GET /api/plex/movies?section=1`
- `GET /api/plex/search?q=matrix`
- `GET /api/plex/movies/{ratingKey}`
- `GET /api/plex/movies/{ratingKey}/poster`
- `GET /api/plex/movies/{ratingKey}/play`

The Worker keeps the token on the server. Poster and playback requests are proxied through the Worker; video Range headers are forwarded to support seeking where Plex supports it.

## Important network requirement

Cloudflare must be able to reach your Plex server from the public internet over HTTPS. A Plex server available only on your home Wi-Fi, localhost, or a private LAN IP will not work from Cloudflare. Do not expose an unsecured Plex server publicly.

## Existing catalogue API

Your existing Worker already contains D1-backed routes such as `GET /api/movies` for titles published with rights verified. These Plex endpoints are separate: they list media already present in your Plex library. They do not automatically add those titles to D1.

## Rights

Having a movie in Plex does not prove that you have permission to stream or commercially distribute it. Only expose titles for which you have the required rights in the territories where NOCTURA operates.
