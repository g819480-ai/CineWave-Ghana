CINEWAVE GHANA — SECURITY + DATABASE + ADS STARTER
=================================================

WHAT IS INCLUDED
- index.html: existing CineWave Ghana black/red front-end, updated for API movie data, direct MP4/authorized embeds, subtitles, and ad slots. It keeps a local preview catalogue if the API is unavailable.
- admin.html: protected movie catalogue editor and ad settings.
- worker.js: Cloudflare Worker API with signed HttpOnly session cookie, server-side password check, same-origin checks, input validation, and CRUD routes.
- schema.sql: Cloudflare D1 database schema.
- wrangler.toml: deployment starter.
- movies.js: cleaned reference catalogue; index.html uses the database API after it is configured.

IMPORTANT HONEST LIMITS
This package is a deployable starter, not an already deployed or fully tested live service. It has not been connected to your Cloudflare account, D1 database, or Google AdSense account. Do not expect admin/database/real ad serving to work until the setup steps below are completed.

DEPLOY WITH CLOUDFLARE
1. Keep a backup of your current site files. Extract this ZIP on a computer if possible.
2. Install Node.js and Wrangler on a computer: npm install -g wrangler; then run wrangler login. iPhone-only deployment is difficult because these steps use a terminal.
3. From this project folder, create a D1 database: wrangler d1 create cinewave-ghana-db. Copy the returned database_id into wrangler.toml, replacing REPLACE_WITH_YOUR_D1_DATABASE_ID.
4. Create the schema: wrangler d1 execute cinewave-ghana-db --remote --file=schema.sql
5. Set secrets: wrangler secret put ADMIN_PASSWORD (choose a long unique password), then wrangler secret put SESSION_SECRET (use a long random secret, at least 32 random characters). Do not put either secret in HTML, Git, or wrangler.toml.
6. Deploy: wrangler deploy. If your existing site is on Cloudflare Pages rather than a Worker with Assets, deployment wiring differs; do not overwrite the live site until the Worker and asset routing are configured.
7. Visit /admin.html, sign in, and add a film. The public API will only show it after rights_verified and published are both checked and a valid source is configured.

MOVIE SOURCE RULES
- MP4: use a direct HTTPS URL that you control or are authorized to embed; the host must allow browser playback and range requests.
- Embed: use the exact HTTPS embed URL that the rights holder permits.
- Archive: use the Archive.org item identifier only after checking the item/source licence and your Ghana streaming rights. Public-domain status can vary by territory and source copy.
- A subtitle is a separate HTTPS WebVTT (.vtt) file, with matching language code, e.g. [{"lang":"en","label":"English","url":"https://your-domain.example/subtitles/movie-en.vtt"}]. A language in the menu does not automatically create subtitles.

ADS
1. Apply for and complete approval with your ad provider (for example, Google AdSense). Approval is not guaranteed.
2. Copy your real publisher ID (ca-pub-...) and ad slot IDs into Admin > Advertisement settings.
3. Enable ads only after the website and required privacy/legal disclosures meet the ad provider's policies. Do not click your own ads or encourage invalid clicks.
4. Ads remain hidden if IDs are missing/invalid. Test that ads do not cover controls or interrupt a film.

SECURITY
- Admin password and session signing key are Worker secrets, never frontend code.
- Session cookie is HttpOnly, Secure, SameSite=Strict, and expires after 8 hours.
- Public movie endpoint only exposes published records marked rights-verified. This is an operational safeguard, not proof of ownership or a legal determination.
- Add Cloudflare rate limiting / bot protection to the login endpoint before public launch. Rotate secrets if exposed.
- No user accounts, payments, DRM, upload storage, or ad revenue tracking are included.

TEST BEFORE LAUNCH
- Test /api/movies and /api/ads; both should return JSON after deploy.
- Sign in at /admin.html, add a draft movie, publish it after rights/source verification, then confirm it appears on the homepage.
- Test MP4 and subtitle tracks on iPhone Safari and Android Chrome.
- Test invalid login, logout, unverified title filtering, ad disabled state, and mobile layout.
